#include <bits/stdc++.h>
using namespace std;



int main(){
    string s;
    cin >> s;
    cout << s.substr(0, 4) << endl;

    return 0;
}