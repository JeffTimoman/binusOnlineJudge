
		// printf("Simpan2 = %d\n", simpan2);